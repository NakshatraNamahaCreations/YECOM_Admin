import * as React from "react";
import "./style/useraction.css";
// import { Button } from "react-bootstrap";
// import { Step, Stepper } from "react-form-stepper";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";

const steps = [
  "Choose Channel",
  "Set Audience",
  "Add Content",
  "Publish Campaign",
];

function UserAction() {
  const [activeStep, setActiveStep] = React.useState(0);
  const [skipped, setSkipped] = React.useState(new Set());

  const isStepOptional = (step) => {
    return step === 1;
  };

  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  const handleNext = () => {
    let newSkipped = skipped;
    if (isStepSkipped(activeStep)) {
      newSkipped = new Set(newSkipped.values());
      newSkipped.delete(activeStep);
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped(newSkipped);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSkip = () => {
    if (!isStepOptional(activeStep)) {
      // You probably want to guard against something like this,
      // it should never occur unless someone's actively trying to break something.
      throw new Error("You can't skip a step that isn't optional.");
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped((prevSkipped) => {
      const newSkipped = new Set(prevSkipped.values());
      newSkipped.add(activeStep);
      return newSkipped;
    });
  };

  const handleReset = () => {
    setActiveStep(0);
  };
  return (
    <div class="addCourseMain-0-1-698 mt-3 p-5">
      <div class="stepperContainer-0-1-705">
        <div class="stepper-0-1-716 stepper-d8-0-1-1351">
          <ol class="step-0-1-710">
            <li class="stepItem-0-1-714 active">
              <h3 class="stepTitle-0-1-711">
                <span class="stepTitleText-0-1-715">Choose Channel</span>
              </h3>
              <hr class="progress" />
            </li>
            <li class="stepItem-0-1-714 ">
              <h3 class="stepTitle-0-1-711">
                <span class="stepTitleText-0-1-715">Set Audience</span>
              </h3>
              <hr class="progress" />
            </li>
            <li class="stepItem-0-1-714 ">
              <h3 class="stepTitle-0-1-711">
                <span class="stepTitleText-0-1-715">Add Content</span>
              </h3>
              <hr class="progress" />
            </li>
            <li class="stepItem-0-1-714 ">
              <h3 class="stepTitle-0-1-711">
                <span class="stepTitleText-0-1-715">Publish Campaign</span>
              </h3>
              <hr class="progress" />
            </li>
          </ol>
        </div>
      </div>
      <Stepper activeStep={1}>
        <Step label="Children Step 1" />
        <Step label="Children Step 2" />
        <Step label="Children Step 3" />
      </Stepper>
      <div class="addCourseSection-0-1-699" style={{ height: "60vh" }}>
        <div class="addCourseForm-0-1-700">
          <div class="sectionContainer-0-1-723">
            <div class="marginLeft-0-1-718">
              <div class="abountInfo-0-1-719">
                I want to send communication via
              </div>
              <div>
                <div class="radioInputTagContainer-0-1-720">
                  <div class="radioBtnWrap-0-1-732">
                    <label
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        fontWeight: "700",
                      }}
                    >
                      <div class="tooltipWrapper-0-1-734">
                        <div
                          class="tooltipTip-0-1-735 top-0-1-736"
                          style={{ top: "-53.5938px", opacity: "0" }}
                        >
                          Channel change is disabled
                        </div>
                        <input
                          type="radio"
                          name="webinar"
                          value=""
                          style={{ margin: "0px 8px" }}
                        />
                      </div>
                      <div>Push Notification</div>
                    </label>
                  </div>
                  <div class="radioBtnWrap-0-1-732">
                    <label
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        fontWeight: "700",
                      }}
                    >
                      <div class="tooltipWrapper-0-1-734">
                        <div
                          class="tooltipTip-0-1-735 top-0-1-736"
                          style={{ top: "-53.5938px", opacity: "0" }}
                        >
                          Channel change is disabled
                        </div>
                        <input
                          type="radio"
                          name="webinar"
                          value=""
                          style={{ margin: "0px 8px" }}
                        />
                      </div>
                      <div>Email</div>
                    </label>
                  </div>
                  <div class="radioBtnWrap-0-1-732">
                    <label
                      style={{
                        display: "flex",
                        flexDirection: "row",
                        fontWeight: "700",
                      }}
                    >
                      <div class="tooltipWrapper-0-1-734">
                        <div
                          class="tooltipTip-0-1-735 top-0-1-736"
                          style={{ top: "-53.5938px", opacity: "0" }}
                        >
                          Channel change is disabled
                        </div>
                        <input
                          type="radio"
                          name="webinar"
                          value=""
                          style={{ margin: "0px 8px" }}
                        />
                      </div>
                      <div>SMS</div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="footerNavContainer-0-1-444 footerNavContainer-d0-0-1-457">
              <Button
                className="px-5 py-2"
                variant="outline-info"
                onClick={() => window.location.assign("/campaigns/create")}
              >
                Back
              </Button>{" "}
              <Button className="ms-2 px-5" variant="info">
                Set Target Audience
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserAction;
